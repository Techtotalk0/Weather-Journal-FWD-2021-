//Setup endpoint
project_data=[];

//for Express
const express = require('express');

//start up an instance
const ins = express();

/*The dependencies*/
const body_parser = require('body-parser');

/*Middle*/
//For configuring express
ins.use(body_parser.urlencoded({extended: false}));
ins.use(body_parser.json());

//cross allowance
const cor = require('cors');
ins.use(cor());

//start project
ins.use(express.static('website'));

//port setup
const _port = 8000;

//spinning up
const _server = ins.listen(_port, _listening);

//For debugging
function _listening()
{
  console.log('Server is running');
  console.log(`Running on localhost port number: ${_port}`);
} 

//start routes
ins.get('/all', send_data);

//start GET request
function send_data(request, respond)
{
respond.send(project_data);
project_data =[];
}

//routes for post request

ins.post('/add', add_data);

function add_data(request, respond)
{
  console.log(request.body);
  Newentry =
  {
       date: request.body.date,
       temp: request.body.temp,
       content: request.body.content
  }
  project_data.push(Newentry);
}